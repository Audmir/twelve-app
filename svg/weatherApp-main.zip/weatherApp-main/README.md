# weatherApp
fetch weather data from an API with js
